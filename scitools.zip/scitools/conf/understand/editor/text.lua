-- Plain Text
return {
  name = "Plain Text",
  lexer = 1,
  extensions = "txt"
}