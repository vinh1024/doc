namespace System
{
   public struct Int64
   {
   }
}
