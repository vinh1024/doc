namespace System
{
   public sealed class StackOverflowException : SystemException
   {
      public StackOverflowException();
      public StackOverflowException(string message);
      public StackOverflowException(string message, Exception innerException);
   }
}
