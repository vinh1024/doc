namespace System.Collections
{
   public interface IEnumerable
   {
      public IEnumerator GetEnumerator();
   }
}
