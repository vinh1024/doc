namespace System
{
   public interface IDisposable
   {
      public void Dispose();
   }
}
