namespace System
{
   public struct SByte
   {
   }
}
