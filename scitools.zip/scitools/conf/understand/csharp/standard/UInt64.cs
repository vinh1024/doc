namespace System
{
   public struct UInt64
   {
   }
}
