namespace System
{
   public abstract class ValueType
   {
      protected ValueType();
   }
}
