namespace System
{
   public abstract class Type : MemberInfo
   {
   }
}
