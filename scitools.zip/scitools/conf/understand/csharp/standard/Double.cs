namespace System
{
   public struct Double
   {
   }
}