# Functions
def displayhook(): pass
__displayhook__ = displayhook;
def excepthook(): pass
__excepthook__ = excepthook;
def call_tracing(): pass
def callstats(): pass
def displayhook(): pass
def exc_clear(): pass
def exc_info(): pass
def excepthook(): pass
def exit(): pass
def getcheckinterval(): pass
def getdefaultencoding(): pass
def getfilesystemencoding(): pass
def getprofile(): pass
def getrecursionlimit(): pass
def getrefcount(): pass
def getsizeof(): pass
def gettrace(): pass
def getwindowsversion(): pass
def setcheckinterval(): pass
def setprofile(): pass
def setrecursionlimit(): pass
def settrace(): pass
# DATA
__stderr__ = 1
__stdin__ = 1
__stdout__ = 1
api_version = 1013
argv = ['']
builtin_module_names = ()
byteorder = ''
copyright = ''
dllhandle = 503316480L
dont_write_bytecode = False
exc_value = ""
exec_prefix = r'C:\Python27'
executable = r'C:\Python27\python.exe'
flags = sys.flags()
float_info = sys.float_info(max=1.7976931348623157e+308, )
float_repr_style = 'short'
hexversion = 34013680
long_info = sys.long_info(bits_per_digit=30, sizeof_digit=4)
maxint = 2147483647
maxsize = 9223372036854775807L
maxunicode = 65535
meta_path = []
modules = {}
path = []
path_hooks = []
path_importer_cache = {}
platform = 'win32'
prefix = r'C:\Python27'
ps1 = '>>> '
ps2 = '... '
py3kwarning = False
stderr = 1
stdin = 1
stdout = 1
subversion = ('')
version = ''
version_info = 1
warnoptions = []
winver = ''
