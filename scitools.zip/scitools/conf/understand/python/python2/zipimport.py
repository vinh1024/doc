import __builtin__
import exceptions

class ZipImportError(exceptions.ImportError):
     __weakref__ = 0

class zipimporter(__builtin__.object):
     def __getattribute__(): pass
     def __init__(): pass
     def __repr__(): pass
     def find_module(): pass
     def get_code(): pass
     def get_data(): pass
     def get_filename(): pass
     def get_source(): pass
     def is_package(): pass
     def load_module(): pass
     archive = 0
     prefix = 0
     __new__ = 0
