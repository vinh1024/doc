def acos(x): pass
def acosh(x): pass
def asin(x): pass
def asinh(x): pass
def atan(x): pass
def atan2(y, x): pass
def atanh(x): pass
def ceil(x): pass
def copysign(x, y): pass
def cos(x): pass
def cosh(x): pass
def degrees(x): pass
def erf(x): pass
def erfc(x): pass
def exp(x): pass
def expm1(x): pass
def fabs(x): pass
def factorial(x): pass
def floor(x): pass
def fmod(x, y): pass
def frexp(x): pass
def fsum(iterable): pass
def gamma(x): pass
def hypot(x, y): pass
def isinf(x): pass
def isnan(x): pass
def ldexp(x,i): pass
def lgamma(x): pass
def log(x, base): pass
def log10(x): pass
def log1p(x): pass
def modf(x): pass
def pow(x, y): pass
def radians(x): pass
def sin(x): pass
def sinh(x): pass
def sqrt(x): pass
def tan(x): pass
def tanh(x): pass
def trunc(x): pass
e = 2.718281828459045
pi = 3.141592653589793
