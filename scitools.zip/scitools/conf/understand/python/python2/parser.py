import __builtin__
import exceptions

class st(__builtin__.object):
     def __cmp__(): pass
     
ASTType = st

class ParserError(exceptions.Exception):
     __weakref__ = 0
     
STType = st

def ast2list(): pass
def ast2tuple(): pass
def compileast(): pass
def compilest(): pass
def expr(): pass
def isexpr(): pass
def issuite(): pass
def sequence2ast(): pass
def sequence2st(): pass
def st2list(): pass
def st2tuple(): pass
def suite(): pass
def tuple2ast(): pass
def tuple2st(): pass
__copyright__ = ''
__version__ = '0.5'

