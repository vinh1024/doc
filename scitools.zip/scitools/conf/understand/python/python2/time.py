import __builtin__

class struct_time(__builtin__.object):
     def __add__(): pass
     def __contains__(): pass
     def __eq__(): pass
     def __ge__(): pass
     def __getitem__(): pass
     def __getslice__(): pass
     def __gt__(): pass
     def __hash__(): pass
     def __le__(): pass
     def __len__(): pass
     def __lt__(): pass
     def __mul__(): pass
     def __ne__(): pass
     def __reduce__(): pass
     def __repr__(): pass
     def __rmul__(): pass
     tm_hour = 0
     tm_isdst = 0
     tm_mday = 0
     tm_min = 0
     tm_mon = 0
     tm_sec = 0
     tm_wday = 0
     tm_yday = 0
     tm_year = 0
     __new__ = 0
     n_fields = 9
     n_sequence_fields = 9
     n_unnamed_fields = 0

def asctime(): pass
def clock(): pass
def ctime(): pass
def gmtime(): pass
def localtime(): pass
def mktime(): pass
def sleep(): pass
def strftime(): pass
def strptime(): pass
def time(): pass
accept2dyear = 1
altzone = 14400
daylight = 1
timezone = 18000
tzname = ('Eastern Standard Time', 'Eastern Daylight Time')
