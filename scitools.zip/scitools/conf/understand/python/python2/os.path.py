# FUNCTIONS
def abspath(path):
   pass
    
def basename(p):
   pass
    
def commonprefix(m):
   pass
    
def dirname(p):
   pass
    
def exists(path):
   pass
    
def expanduser(path):
   pass
   
def expandvars(path):
   pass
    
def getatime(filename):
   pass
    
def getctime(filename):
   pass
    
def getmtime(filename):
   pass
    
def getsize(filename):
   pass
    
def isabs(s):
   pass
    
def isdir():
   pass
    
def isfile(path):
   pass
    
def islink(path):
   pass
    
def ismount(path):
   pass
    
def join(path, *paths):
   pass
    
def lexists():
   pass
    
def normcase(s):
   pass
    
def normpath(path):
   pass
    
def realpath(path):
   pass
    
def relpath(path, start='.'):
   pass
    
def split(p):
   pass
    
def splitdrive(p):
   pass
    
def splitext(p):
   pass
    
def splitunc(p):
   pass
        
def walk(top, func, arg):
   pass

# DATA
altsep = '/'
curdir = '.'
defpath = r'.;C:\bin'
devnull = 'nul'
extsep = '.'
pardir = '..'
pathsep = ';'
sep = r'\\'
supports_unicode_filenames = True
