import __builtin__

class spamdict(__builtin__.dict):
     def __init__(): pass
     def getstate(): pass
     def setstate(): pass
     
     state = 0
     
class spamlist(__builtin__.list):
     def __init__(): pass
     def getstate(): pass
     def setstate(): pass
     def staticmeth(): pass
     classmeth = 0
     
def bench(): pass
