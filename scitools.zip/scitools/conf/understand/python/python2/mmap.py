import __builtin__
import exceptions

class error(exceptions.EnvironmentError):
     __weakref__ = []
     
class mmap(__builtin__.object):
     def __add__(): pass
     def __delitem__(): pass
     def __delslice__(): pass
     def __getattribute__(): pass
     def __getitem__(): pass
     def __getslice__(): pass
     def __len__(): pass
     def __mul__(): pass
     def __rmul__(): pass
     def __setitem__(): pass
     def __setslice__(): pass
     def close(): pass
     def find(): pass
     def  flush(): pass
     def move(): pass
     def read(): pass
     def read_byte(): pass
     def readline(): pass
     def resize(): pass
     def rfind(): pass
     def seek(): pass
     def size(): pass
     def tell(): pass
     def write(): pass
     def write_byte(): pass
     __new__ = 0

ACCESS_COPY = 3
ACCESS_READ = 1
ACCESS_WRITE = 2
ALLOCATIONGRANULARITY = 65536
PAGESIZE = 4096
