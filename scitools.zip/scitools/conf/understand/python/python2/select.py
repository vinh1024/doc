import exceptions

class error(exceptions.Exception):
   pass

def select():
   pass
