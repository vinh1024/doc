# Functions:
def alarm(): pass 
def setitimer(): pass 
def getitimer(): pass 
def signal(): pass 
def getsignal(): pass 
def pause(): pass 
def default_int_handler(): pass 
    
#DATA
CTRL_BREAK_EVENT = 1
CTRL_C_EVENT = 0
NSIG = 23
SIGABRT = 22
SIGBREAK = 21
SIGFPE = 8
SIGILL = 4
SIGINT = 2
SIGSEGV = 11
SIGTERM = 15
SIG_DFL = 0
SIG_IGN = 1


