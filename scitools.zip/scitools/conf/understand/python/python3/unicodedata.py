# CLASSES
class UCD:
   def bidirectional(): pass
   def category(): pass
   def combining(): pass
   def decimal(): pass
   def decomposition(): pass
   def digit(): pass
   def east_asian_width(): pass
   def lookup(): pass
   def mirrored(): pass
   def name(): pass
   def normalize(): pass
   def numeric(): pass
   unidata_version = 1
   
# FUNCTIONS
def bidirectional(): pass
def category(): pass
def combining(): pass
def decimal(): pass
def decomposition(): pass
def digit(): pass
def east_asian_width(): pass
def lookup(): pass
def mirrored(): pass
def name(): pass
def normalize(): pass
def numeric(): pass

# DATA
ucd_3_2_0 = "unicodedata.UCD object"
ucnhash_CAPI = "unicodedata.ucnhash_CAPI"
unidata_version = '9.0.0'


